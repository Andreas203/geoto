package com.example.geoto.database;

public interface ReadingDAO {
}
