package com.example.geoto.database;

public abstract class ReadingData {
}
