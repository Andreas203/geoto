package com.example.geoto.database;

public interface PhotoDAO {
}
