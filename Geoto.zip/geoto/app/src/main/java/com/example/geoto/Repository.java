package com.example.geoto;

public class Repository {

}
